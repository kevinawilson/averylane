<div class="top-bar" id="menu-main-menu">
	<div class="top-bar-left">
		<ul class="menu">
			<li><a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a></li>
		</ul>
	</div>
	<div class="top-bar-right">
		<div class="phone">
			<?php echo get_option( 'al_phone' ); ?>
		</div>
	</div>
</div>
