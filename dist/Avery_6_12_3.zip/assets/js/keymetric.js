var KmHost = (("https:" == document.location.protocol) ? "https://km14368" : "http://km14368");
var kmscr = document.createElement('script');

kmscr.type = 'text/javascript';
kmscr.src = KmHost + ".keymetric.net/KeyMetric.js";
document.body.appendChild(kmscr);