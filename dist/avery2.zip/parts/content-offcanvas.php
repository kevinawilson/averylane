<div class="off-canvas position-left" id="off-canvas" data-off-canvas data-position="left">
	<?php joints_off_canvas_nav(); ?>
</div>

<!-- <div class="off-canvas dropdown-pane" id="off-canvas" data-dropdown data-auto-focus="true" style="z-index: 5;">
    <?php joints_off_canvas_nav(); ?>
</div> -->
